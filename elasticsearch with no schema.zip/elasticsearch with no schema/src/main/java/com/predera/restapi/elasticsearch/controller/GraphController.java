package com.predera.restapi.elasticsearch.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.predera.restapi.elasticsearch.load.Loaders;
import com.predera.restapi.elasticsearch.model.Model;
import com.predera.restapi.elasticsearch.repository.ModelRepository;

@RestController

public class GraphController {
 
    @Autowired
    ModelRepository modelRepository;
    
    @Autowired
    Loaders loader;
    
    /*
    * URL mapping to search all users
    */
    @GetMapping(value = "churn/all")
    public List<Model> searchAll() {
        List<Model> graphList = new ArrayList<>();
        Iterable<Model> listOfGraph = modelRepository.findAll();
        listOfGraph.forEach(graphList::add);
        return graphList;
    }
    
    /*
    * URL mapping to save user
    */
    @PostMapping(value = "churn/save")
    public void save(@RequestBody Model listOfGraph) {
        System.out.println(listOfGraph);
        loader.getData(listOfGraph);
    }  
    
    /*
     * URL mapping to update user
     */
     @PutMapping(value = "churn/update")
     public void update(@RequestBody Model listOfGraph) {
         System.out.println(listOfGraph);
         loader.getData(listOfGraph);
     }
    
    /*
     * URL mapping to delete user by id
     */
     @GetMapping(value = "churn/delete/{id}")
     public void delete(@PathVariable final String id) {
         modelRepository.delete(id);
     }
}
