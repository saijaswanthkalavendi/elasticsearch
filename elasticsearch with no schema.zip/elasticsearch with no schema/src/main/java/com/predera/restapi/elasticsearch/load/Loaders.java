/*
* This java file loads data when ever user tries to save a new record.
*/
package com.predera.restapi.elasticsearch.load;

import com.predera.restapi.elasticsearch.model.Model;
import com.predera.restapi.elasticsearch.model.Users;
import com.predera.restapi.elasticsearch.repository.UsersRepository;
import com.predera.restapi.elasticsearch.repository.ModelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import javax.annotation.PostConstruct;

@Component
public class Loaders {
    @Autowired
    ElasticsearchOperations operations;
    
   
    
    @Autowired
    ModelRepository modelRepository;
    
    @Autowired
    UsersRepository usersRepository;
    
    @PostConstruct
    @Transactional
    public void loadAll(){
        
        operations.putMapping(Users.class);
        System.out.println("Loading Data");
    }
    
    public Object getData(Users listOfUsers) {
        /*List<Users> listOfUsers = new ArrayList<>();
        userses.add(new Users("Ajay",123L, "Accounting", 12000L));
        userses.add(new Users("Jaga",1234L, "Finance", 22000L));
        userses.add(new Users("Thiru",1235L, "Accounting", 12000L));*/
        System.out.println(listOfUsers);
        return usersRepository.save(listOfUsers);
        //return listOfUsers;
    }
    
    public Object getData(Model listOfGraph) {
    	System.out.println(listOfGraph);
        return modelRepository.save(listOfGraph);
    	
    }
}