/*
 *Interface defining CRUD operations
 */

package com.predera.restapi.elasticsearch.repository;

import java.util.List;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import com.predera.restapi.elasticsearch.model.Users;

@SuppressWarnings("unchecked")
public interface UsersRepository extends ElasticsearchRepository<Users, Long> {
    List<Users> findByName(String text);
    
    List<Users> findByid(Long id);
    
    public void delete(Long id);
    
    public Users save(Users listOfUsers);
    
}
