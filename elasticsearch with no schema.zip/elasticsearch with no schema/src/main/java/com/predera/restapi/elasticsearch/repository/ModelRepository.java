package com.predera.restapi.elasticsearch.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import com.predera.restapi.elasticsearch.model.Model;

@SuppressWarnings("unchecked")
public interface ModelRepository extends ElasticsearchRepository<Model, String> {
	
	public void delete(String id);
	public Model save(Model listOfUsers);	 
}
