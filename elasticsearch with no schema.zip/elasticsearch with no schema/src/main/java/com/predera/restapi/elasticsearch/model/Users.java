/*
 *  This java file is a pojo which contains all the attributes of the users
 */

package com.predera.restapi.elasticsearch.model;

import java.util.Map;

import org.springframework.data.elasticsearch.annotations.Document;

@Document(indexName = "users", type = "users", shards = 1)
public class Users {
    
    private String name;
    private Long id;
    private String teamName;
    private Long salary;
    private Map<String,String> someJson;
    
    public Users() {
    }
        
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getTeamName() {
        return teamName;
    }
    
    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }
    
    public Long getSalary() {
        return salary;
    }
    
    public void setSalary(Long salary) {
        this.salary = salary;
    }
    
    public Users(String name, Long id, String teamName, Long salary) {
        
        this.name = name;
        this.id = id;
        this.teamName = teamName;
        this.salary = salary;
    }
    
    public Map<String, String> getSomeJson() {
		return someJson;
	}

	public void setSomeJson(Map<String, String> someJson) {
		this.someJson = someJson;
	}

	@Override
    public String toString() {
        return "\nName: " + this.name +
        "\nId: " + this.id +
        "\nTeam " + this.teamName +
        "\nSalary: " + this.salary + "\n";
    }
}