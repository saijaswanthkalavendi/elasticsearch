/*
* This is SearchController where routing for every request is done.
*/
package com.predera.restapi.elasticsearch.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.predera.restapi.elasticsearch.load.Loaders;
import com.predera.restapi.elasticsearch.model.Users;
import com.predera.restapi.elasticsearch.repository.UsersRepository;

@RestController

public class SearchController {
    
    @Autowired
    UsersRepository usersRepository;
    
    @Autowired
    Loaders loader;
    
    
    /* 
     * Basic URL mapping
     */
    
    @RequestMapping("/")
    public String Welcome() {
        return "Welcome to Spring boot ElasticSearch example";
    }
    
    
    /*
     *  URL mapping to search user by name
     */
    
    @GetMapping(value = "/name/{text}")
    public List<Users> searchName(@PathVariable final String text) {
        return usersRepository.findByName(text);
    }
    
    
    /*
     *  URL mapping to search user by id
     */
    
    @GetMapping(value = "/id/{id}")
    public List<Users> searchid(@PathVariable final Long id) {
        return usersRepository.findByid(id);
    }
    
    
    /*
     *  URL mapping to delete user by id
     */
    
    @GetMapping(value = "/delete/{id}")
    public void delete(@PathVariable final Long id) {
        usersRepository.delete(id);
    }
    
    
    /*
     *  URL mapping to search all users
     */
    
    @GetMapping(value = "/all")
    public List<Users> searchAll() {
        List<Users> usersList = new ArrayList<>();
        Iterable<Users> listOfUsers = usersRepository.findAll();
        listOfUsers.forEach(usersList::add);
        return usersList;
    }
    
    
    /*
     * URL mapping to save user
     */
    
    @PostMapping(value = "/save")
    public void save(@RequestBody Users listOfUsers) {
        System.out.println(listOfUsers);
        loader.getData(listOfUsers);
    }
    
    
    /*
     *  URL mapping to update user
     */
    
    @PutMapping(value = "/update")
    public void update(@RequestBody Users listOfUsers) {
        System.out.println(listOfUsers);
        loader.getData(listOfUsers);
    }
    
}
