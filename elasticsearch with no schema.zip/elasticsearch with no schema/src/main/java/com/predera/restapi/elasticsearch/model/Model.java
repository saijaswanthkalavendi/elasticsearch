package com.predera.restapi.elasticsearch.model;

import java.util.List;

import org.springframework.data.elasticsearch.annotations.Document;

@Document(indexName = "model", type = "model", shards = 2)
public class Model {

	private String id;
	private String name;
	private String type;
	private String algorithm;
	private String train_data;
	private Float accuracy;
	private Float auc;
	private List<List<Double>> lift_points;
	private Float recall;
	private List<List<Double>> roc_points;
	private Float precision;
	private Float fScore;
	private Float support;
	private List<List<Double>> confusion_matrix;
	private String status;
    private String owner;
	
	Model() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAlgorithm() {
		return algorithm;
	}

	public void setAlgorithm(String algorithm) {
		this.algorithm = algorithm;
	}

	public String getTrain_data() {
		return train_data;
	}

	public void setTrain_data(String train_data) {
		this.train_data = train_data;
	}

	public Float getAccuracy() {
		return accuracy;
	}

	public void setAccuracy(Float accuracy) {
		this.accuracy = accuracy;
	}

	public Float getAuc() {
		return auc;
	}

	public void setAuc(Float auc) {
		this.auc = auc;
	}

	public List<List<Double>> getLift_points() {
		return lift_points;
	}

	public void setLift_points(List<List<Double>> lift_points) {
		this.lift_points = lift_points;
	}

	public Float getRecall() {
		return recall;
	}

	public void setRecall(Float recall) {
		this.recall = recall;
	}

	public List<List<Double>> getRoc_points() {
		return roc_points;
	}

	public void setRoc_points(List<List<Double>> roc_points) {
		this.roc_points = roc_points;
	}

	public List<List<Double>> getConfusion_matrix() {
		return confusion_matrix;
	}

	public void setConfusion_matrix(List<List<Double>> confusion_matrix) {
		this.confusion_matrix = confusion_matrix;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public Float getPrecision() {
		return precision;
	}

	public void setPrecision(Float precision) {
		this.precision = precision;
	}

	public Float getfScore() {
		return fScore;
	}

	public void setfScore(Float fScore) {
		this.fScore = fScore;
	}

	public Float getSupport() {
		return support;
	}

	public void setSupport(Float support) {
		this.support = support;
	}


}
